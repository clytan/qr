Hello (User Name),

A warm welcome to our digital community - Zokli. We are building world's largest ever digital social media community. A ten million strong, diverse digital youths across India.

"ZOKLI" : Connect-Create-Communicate

A digital social media community, connecting via dynamic QR code (Single QR code for all of your contact details & social media links)

Make Every Day, Your Lucky Day with the Zokli Community. Ready to turn your ordinary days into extraordinarily lucky days? Check it out !!!

 🛑 For Individuals & Creators :

Participate in Zokli’s exclusive reward based community activities, complete 10 daily tasks / activities online (Every Hour, 333 days) of the community and stand a chance to win amazing rewards & recognition, every single day !!!

Zokli Community Tasks / Activities are simple & easy to complete, just Subscribe & follow requests, brand ads, brand video views & community creators video views, which you will receive through notifications via app, So download Zokli app. Win following rewards daily !!!


✓ Brand new Apple iPhone 17 up for grabs daily.
✓ Android phones to be won every day.
✓ Hundreds of One Lakh Rupees worth of cash coupons daily, because winning cash makes every day better!
✓ Fully paid Dubai & Goa trips and enjoy sun, sand, and fun at the top tourist destinations.
✓ Win Amazon - Flipkart coupons everyday.
✓ Win Shopping coupons everyday.
✓ Win games - Play coupons daily.
✓ Win Gold & Silver personalised QR codes.
✓ Exclusive reference bonus (For Individuals Rs 100/- & for Creators Rs 200/-) for every successful references. 
✓ Get huge community discounts on top brands
✓ Get IPL tickets to watch your favourite teams playing in your city.
✓ Weekend Party / Event tickets to top clubs with beverages & food.
✓ Play games on our app & win big !


✓ Amazing community support for Creators ecomomy & their contents.
✓ Brand exposure to our community creators.
✓ Readily available brand contracts / barter deals to our community Creators.


"Mega prize" is truly spectacular : 
 ✓ Win 2026- Tomorrow Land" fully paid tickets! Immerse yourself in the world’s greatest music festival, with absolutely everything covered.
✓ Win Super Bikes.
✓ Win SUV Cars.

 🛑 For Business :

Get your business a dynamic QR code from Zokli & promote your business within our community.
✓ Get upto "100 crores" of funding assistance for 100 startups / existing businesses.
✓ Get marketing and sales support from the Zokli community.

*How to participate & win?

At Zokli, immerse yourself into community activities, and let the fortune favor you. The more you engage, the more chances to win. Make every day, your lucky day with Zokli - Community!!!

*Zokli Community Programs :

1) Zokli Community city-wise get together & meet & greet events.
2) Zokli Community dating activities.
3) Zokli Community merchandise sales.
4) Zokli Community partner program (Sell Insurance , mutual funds, Edu tech products,& real estate and earn)business opportunities.
5) Zokli Community job creation programs.
6) Zokli Community startup creation programs.
7) Zokli Community freelancers support programs.
8) Zokli Community creators economy creation & support programs.
9) Zokli Community gaming support programs.
10) Zokli Community technical & skill education support programs.


Visit - www.zokli.io

Download our apps from the Apple Store & Play Store.


Follow us on : Instagram - Facebook - X - Linkedin - Telegram - Youtube.



Best Regards from,

Zokli India
