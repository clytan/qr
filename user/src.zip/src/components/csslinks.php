<link id="bootstrap" href="../assets/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
<link id="bootstrap-grid" href="../assets/css/bootstrap-grid.min.css" rel="stylesheet" type="text/css" />
<link id="bootstrap-reboot" href="../assets/css/bootstrap-reboot.min.css" rel="stylesheet" type="text/css" />
<link href="../assets/css/animate.css" rel="stylesheet" type="text/css" />
<link href="../assets/css/owl.carousel.css" rel="stylesheet" type="text/css" />
<link href="../assets/css/owl.theme.css" rel="stylesheet" type="text/css" />
<link href="../assets/css/owl.transitions.css" rel="stylesheet" type="text/css" />
<link href="../assets/css/magnific-popup.css" rel="stylesheet" type="text/css" />
<link href="../assets/css/jquery.countdown.css" rel="stylesheet" type="text/css" />
<link href="../assets/css/style.css" rel="stylesheet" type="text/css" />
<link href="../assets/css/de-grey.css" rel="stylesheet" type="text/css" />
<!-- color scheme -->
<link id="colors" href="../assets/css/colors/scheme-04.css" rel="stylesheet" type="text/css" />
<link href="../assets/css/coloring.css" rel="stylesheet" type="text/css" />